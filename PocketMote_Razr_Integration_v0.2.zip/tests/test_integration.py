"""Offline test of the exact-match source integration and new resource ordering."""
import importlib.util
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("integration", root / "setup.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

a = '''package dev.lcdclock;
class CoverActivity {
    static final String PAGE_RECORDER = "recorder";
    private void prepare(String next) {
        if (false) { }
        } else if (PAGE_RECORDER.equals(next)) {
            view = new RecorderView(this);
        }
    }
}'''
p = '''class Prefs {
    static final List<String> HOLD_ACTIONS = Arrays.asList(HOLD_NONE, CoverActivity.PAGE_FACE,
            CoverActivity.PAGE_HOME, CoverActivity.PAGE_MUSIC, HOLD_TORCH);
    static final List<String> TABS = Arrays.asList(CoverActivity.PAGE_CLOCK,
            CoverActivity.PAGE_HOME, CoverActivity.PAGE_MUSIC);
}'''
t = '''class TabIcons {
    void draw() {
      switch (page) {
            case CoverActivity.PAGE_HOME: {
              return;
            }
      }
    }
}'''
s = r'''<resources>
    <string-array name="tab_help">
      <item>One</item>
        <item>A tab per app with music, showing the app\'s icon. Opens when music starts.</item>
    </string-array>
    <string-array name="tab_names">
      <item>One</item>
        <item>Music (a tab per app)</item>
    </string-array>
    <string-array name="hold_names">
        <item>Music</item>
    </string-array>
</resources>'''
with tempfile.TemporaryDirectory() as temp:
    dest = Path(temp)
    data = {"src/dev/lcdclock/CoverActivity.java": a,
            "src/dev/lcdclock/Prefs.java": p,
            "src/dev/lcdclock/TabIcons.java": t,
            "res/values/strings.xml": s}
    for name, contents in data.items():
        path = dest / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents)
    mod.apply_patch(dest)
    strings = ET.parse(dest / "res/values/strings.xml").getroot()
    assert strings.find("string-array[@name='tab_names']")[-2].text == "Pocket Mote (virtual pet)"
    assert strings.find("string-array[@name='hold_names']")[-2].text == "Pocket Mote"
    assert "new PetView(this)" in (dest / "src/dev/lcdclock/CoverActivity.java").read_text()
    assert "PAGE_PET" in (dest / "src/dev/lcdclock/Prefs.java").read_text()
    assert (dest / "src/dev/lcdclock/PetView.java").is_file()
print("PASS: source patch, preferences, XML arrays, native files")
