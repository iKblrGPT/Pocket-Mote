#!/usr/bin/env python3
"""Build a modified LCD Clock source tree with a Pocket Mote PET cover-screen page.

Uses the pinned public MIT-licensed upstream revision. No root and no Gradle required.
Run from this folder: python setup.py --download
Or: python setup.py --upstream /path/to/razr-lcd-clock
"""
from __future__ import annotations

import argparse
import io
import re
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

REPO = "z5146542/razr-lcd-clock"
REVISION = "f976f0da54913155c783dd1a8174931f3d959815"  # Oct 17, 2026
BASE = Path(__file__).resolve().parent


def replace_once(source: str, old: str, new: str, filename: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f"{filename}: expected exactly one anchor but found {count}: {old!r}")
    return source.replace(old, new, 1)


def append_array_item(source: str, array_name: str, anchor: str, new_item: str) -> str:
    pattern = r'(<string-array name="' + re.escape(array_name) + r'">)(.*?)(</string-array>)'
    hits = list(re.finditer(pattern, source, re.DOTALL))
    if len(hits) != 1:
        raise RuntimeError(f"strings.xml: cannot identify array {array_name}")
    item = hits[0].group(2)
    if item.count(anchor) != 1:
        raise RuntimeError(f"strings.xml: missing or ambiguous array anchor {array_name}")
    newer = item.replace(anchor, new_item + '\n' + anchor, 1)
    m = hits[0]
    return source[:m.start(2)] + newer + source[m.end(2):]


def apply_patch(root: Path) -> None:
    files = {
        name: (root / name).read_text(encoding="utf-8")
        for name in [
            "src/dev/lcdclock/CoverActivity.java",
            "src/dev/lcdclock/Prefs.java",
            "src/dev/lcdclock/TabIcons.java",
            "res/values/strings.xml",
        ]
    }
    file = "src/dev/lcdclock/CoverActivity.java"
    content = files[file]
    content = replace_once(content,
        '    static final String PAGE_RECORDER = "recorder";',
        '    static final String PAGE_RECORDER = "recorder";\n    static final String PAGE_PET = "pet";', file)
    content = replace_once(content,
        '        } else if (PAGE_RECORDER.equals(next)) {',
        '        } else if (PAGE_PET.equals(next)) {\n            view = new PetView(this);\n        } else if (PAGE_RECORDER.equals(next)) {', file)
    files[file] = content

    file = "src/dev/lcdclock/Prefs.java"
    content = files[file]
    content = replace_once(content,
        'CoverActivity.PAGE_HOME, CoverActivity.PAGE_MUSIC, HOLD_TORCH);',
        'CoverActivity.PAGE_HOME, CoverActivity.PAGE_PET, CoverActivity.PAGE_MUSIC, HOLD_TORCH);', file)
    content = replace_once(content,
        'CoverActivity.PAGE_HOME, CoverActivity.PAGE_MUSIC);',
        'CoverActivity.PAGE_HOME, CoverActivity.PAGE_PET, CoverActivity.PAGE_MUSIC);', file)
    files[file] = content

    file = "src/dev/lcdclock/TabIcons.java"
    content = files[file]
    content = replace_once(content,
        '            case CoverActivity.PAGE_HOME: {',
        '''            case CoverActivity.PAGE_PET: {
                // Simple pixel creature icon. No external bitmap or imported image needed.
                fill.setColor(ink);
                canvas.drawRoundRect(cx - 0.34f * s, cy - 0.24f * s,
                        cx + 0.34f * s, cy + 0.39f * s, 0.15f * s, 0.15f * s, fill);
                canvas.drawRect(cx - 0.26f * s, cy - 0.45f * s,
                        cx - 0.10f * s, cy - 0.12f * s, fill);
                canvas.drawRect(cx + 0.10f * s, cy - 0.45f * s,
                        cx + 0.26f * s, cy - 0.12f * s, fill);
                fill.setColor(0xFF080F19);
                canvas.drawRect(cx - 0.19f * s, cy - 0.07f * s,
                        cx - 0.08f * s, cy + 0.05f * s, fill);
                canvas.drawRect(cx + 0.08f * s, cy - 0.07f * s,
                        cx + 0.19f * s, cy + 0.05f * s, fill);
                return;
            }
            case CoverActivity.PAGE_HOME: {''', file)
    files[file] = content

    file = "res/values/strings.xml"
    content = files[file]
    content = append_array_item(content, "tab_names", "        <item>Music (a tab per app)</item>",
        "        <item>Pocket Mote (virtual pet)</item>")
    content = append_array_item(content, "tab_help", "        <item>A tab per app with music, showing the app\\'s icon. Opens when music starts.</item>",
        "        <item>A miniature virtual pet for the Razr cover screen. Feed, play, clean and sleep. Progress is saved, including time away from the screen.</item>")
    content = append_array_item(content, "hold_names", "        <item>Music</item>",
        "        <item>Pocket Mote</item>")
    files[file] = content

    # All anchors must have matched before we write anything.
    for name, content in files.items():
        (root / name).write_text(content, encoding="utf-8")
    for filename in ["PetState.java", "PetView.java"]:
        shutil.copy2(BASE / "native" / filename, root / "src/dev/lcdclock" / filename)
    print("Integrated Pocket Mote PET page, tab/icon, page controls, and settings arrays.")


def download_base(target: Path) -> None:
    url = f"https://codeload.github.com/{REPO}/zip/{REVISION}"
    print(f"Downloading pinned upstream {REPO}@{REVISION[:12]}...")
    with urllib.request.urlopen(url, timeout=45) as response:
        payload = response.read()
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = archive.namelist()
        for info in archive.infolist():
            suffix = Path(*Path(info.filename).parts[1:])
            if not suffix.parts:
                continue
            if ".." in suffix.parts or suffix.is_absolute():
                raise RuntimeError("Unexpected unsafe upstream archive path")
            dest = target / suffix
            if info.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as infile, dest.open("wb") as outfile:
                    shutil.copyfileobj(infile, outfile)
                if dest.suffix == ".sh":
                    dest.chmod(dest.stat().st_mode | 0o111)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--download", action="store_true", help="Download pinned upstream revision")
    src.add_argument("--upstream", type=Path, help="Local checkout of LCD Clock upstream")
    parser.add_argument("--output", type=Path, default=BASE / "out/lcd-clock",
                        help="Output directory for modified source (must not exist)")
    args = parser.parse_args()
    dest = args.output.resolve()
    if dest.exists():
        parser.error(f"Output already exists: {dest}. Choose a fresh --output to protect your files.")
    dest.mkdir(parents=True)
    try:
        if args.download:
            download_base(dest)
        else:
            if not (args.upstream / "AndroidManifest.xml").is_file():
                raise RuntimeError("--upstream must be an extracted LCD Clock checkout")
            shutil.copytree(args.upstream, dest, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns(".git", "build", "lcd-clock.apk", "debug.keystore"))
        apply_patch(dest)
    except Exception as exc:
        shutil.rmtree(dest, ignore_errors=True)
        print(f"Failed: {exc}", file=sys.stderr)
        sys.exit(1)
    print(f"Source ready: {dest}")
    print(f"Build from there: cd {dest} && bash build.sh")
    print("Or use the included GitHub Actions workflow to build an APK in the cloud.")


if __name__ == "__main__":
    main()
