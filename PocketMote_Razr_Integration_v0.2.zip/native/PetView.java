package dev.lcdclock;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;

/** Interactive PET tab, designed directly for the Razr 40's 368x194 cover display. */
final class PetView extends CoverPage {
    private static final int FEED = 1, PLAY = 2, CLEAN = 3, SLEEP = 4;
    private static final int BG = 0xFF080F19;
    private static final int CYAN = 0xFF80E9E1;
    private static final int MINT = 0xFF69D7C6;
    private static final int AMBER = 0xFFFFC77A;
    private static final int SOFT = 0xFFB3CAD2;
    private static final String[] SPRITE = {
            ".....OO..OO.....",
            "....OBBOOBBO....",
            "....OBBBBBBO....",
            "...OBBBBBBBBO...",
            "..OBBBBBBBBBBO..",
            ".OBBBBBBBBBBBBO.",
            ".OBBWWBBBWWBBBO.",
            ".OBBEEBBBEEBBBO.",
            ".OBBBBBBBBBBBBO.",
            ".OBBBBCCCCBBBBO.",
            "..OBBBCCCCBBBO..",
            "...OBBBBBBBBO...",
            "....OBBBBBBO....",
            ".....OO..OO....."
    };

    private final PetState pet;
    private final Paint pixel = new Paint();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!isAttachedToWindow()) return;
            pet.tick(getContext(), System.currentTimeMillis());
            invalidate();
            postDelayed(this, 900);
        }
    };

    PetView(Context context) {
        super(context);
        pet = PetState.load(context);
        text.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        pixel.setAntiAlias(false);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(tick);
        post(tick);
    }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override void drawPage(Canvas canvas, int color) {
        canvas.drawColor(BG);
        // All measurements scale from the canonical 368 x 194 content box.
        float s = bw / 368f;
        canvas.save();
        canvas.translate(bx, by);
        canvas.scale(s, s);
        float y0 = (top - by) / s;
        small(canvas, "POCKET MOTE", 14, y0 + 12, CYAN, 12, Paint.Align.LEFT);
        small(canvas, "DAY " + pet.ageDays(System.currentTimeMillis()), 299, y0 + 12, SOFT, 10, Paint.Align.LEFT);

        status(canvas, "FOOD", pet.food, 16, y0 + 30, AMBER);
        status(canvas, "FUN", pet.fun, 16, y0 + 47, MINT);
        status(canvas, "CLEAN", pet.hygiene, 16, y0 + 64, CYAN);
        status(canvas, "REST", pet.energy, 16, y0 + 81, 0xFFB9ADFF);

        // A stage-specific miniature sprite with a slow bounce/blink; no bitmap interpolation.
        long now = SystemClock.uptimeMillis();
        int stage = pet.stage(System.currentTimeMillis());
        int bob = pet.sleeping ? 2 : ((now / 680) % 2 == 0 ? 0 : -2);
        boolean blink = !pet.sleeping && (now % 4400) < 170;
        drawSprite(canvas, 216, y0 + 25 + bob, stage, blink);
        small(canvas, pet.mood(), 252, y0 + 99, CYAN, 10, Paint.Align.CENTER);
        small(canvas, stage == 0 ? "BABY" : stage == 1 ? "MOTE" : "MOTE+",
                252, y0 + 112, SOFT, 9, Paint.Align.CENTER);

        String[] titles = {"FEED", "PLAY", "CLEAN", pet.sleeping ? "WAKE" : "SLEEP"};
        float buttonY = 161;
        float buttonW = 80;
        for (int i = 0; i < 4; i++) {
            int id = i + 1;
            float x = 12 + i * 88;
            boolean enabled = id == SLEEP || !pet.sleeping && (id != PLAY || pet.energy >= 8);
            RectF local = new RectF(x, buttonY, x + buttonW, 187);
            // CoverPage touch targets use real view coordinates; drawing is inside scaled canvas.
            button(canvas, id, local, id == FEED, enabled, color);
            small(canvas, titles[i], x + buttonW / 2, buttonY + 17,
                    enabled ? (id == FEED ? CYAN : SOFT) : GREY, 11, Paint.Align.CENTER);
            if (enabled) {
                hits.put(id, new RectF(bx + x * s, by + buttonY * s,
                        bx + (x + buttonW) * s, by + 187 * s));
            }
        }
        canvas.restore();
    }

    @Override boolean perform(int id) {
        boolean acted = pet.act(getContext(), id);
        invalidate();
        return acted;
    }

    private void status(Canvas c, String name, int value, float x, float y, int tone) {
        small(c, name, x, y, SOFT, 9, Paint.Align.LEFT);
        float barX = x + 51;
        pixel.setColor(0xFF263746);
        c.drawRoundRect(barX, y - 8, barX + 114, y + 1, 3, 3, pixel);
        pixel.setColor(value < 20 ? 0xFFF36C78 : tone);
        c.drawRoundRect(barX, y - 8, barX + 114 * value / 100f, y + 1, 3, 3, pixel);
        small(c, Integer.toString(value), barX + 118, y, SOFT, 9, Paint.Align.LEFT);
    }

    private void drawSprite(Canvas c, float x, float y, int stage, boolean blink) {
        final int pixelSize = stage == 2 ? 5 : 4;
        float size = pixelSize;
        float spriteWidth = SPRITE[0].length() * size;
        float spriteHeight = SPRITE.length * size;
        float left = x + (72 - spriteWidth) / 2;
        float topSprite = y + (67 - spriteHeight) / 2;
        pixel.setColor(0xFF172A3A);
        c.drawOval(x - 5, y + 63, x + 77, y + 72, pixel);
        for (int row = 0; row < SPRITE.length; row++) {
            String line = SPRITE[row];
            for (int col = 0; col < line.length(); col++) {
                char ch = line.charAt(col);
                if (ch == '.' || ch == 'W' && blink) {
                    if (ch == 'W' && blink) ch = 'B'; else continue;
                }
                int ink;
                switch (ch) {
                    case 'O': ink = 0xFF23404C; break;
                    case 'B': ink = stage == 0 ? 0xFFBC9CFF : stage == 1 ? 0xFF77E0C8 : 0xFFFFD581; break;
                    case 'C': ink = 0xFFFFF2CE; break;
                    case 'W': ink = 0xFFFFFFFF; break;
                    case 'E': ink = pet.sleeping ? 0xFF77E0C8 : 0xFF1B2A39; break;
                    default: continue;
                }
                // Eyes as sleeping slits; no external assets required.
                if (pet.sleeping && ch == 'W') ink = stage == 0 ? 0xFFBC9CFF : 0xFF77E0C8;
                pixel.setColor(ink);
                c.drawRect(left + col * size, topSprite + row * size,
                        left + (col + 1) * size, topSprite + (row + 1) * size, pixel);
            }
        }
    }

    private void small(Canvas canvas, String content, float x, float baseline, int ink,
            float size, Paint.Align alignment) {
        text.setTextSize(size);
        text.setTextAlign(alignment);
        text.setColor(ink);
        canvas.drawText(content, x, baseline, text);
    }
}
