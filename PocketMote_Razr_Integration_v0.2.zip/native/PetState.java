package dev.lcdclock;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persistent clock-based game state. No service, wake lock, network or background loop needed:
 * needs advance from elapsed wall time each time the PET page is opened/used.
 */
final class PetState {
    private static final String STORE = "pocket_mote_v1";
    private static final long MINUTE = 60_000L;
    private static final long HOUR = 60 * MINUTE;
    private static final long DAY = 24 * HOUR;

    long bornAt;
    long updatedAt;
    int food;
    int fun;
    int hygiene;
    int energy;
    boolean sleeping;
    int feeds;
    int plays;
    int cleans;

    private PetState() { }

    static PetState load(Context context) {
        SharedPreferences sp = prefs(context);
        long now = System.currentTimeMillis();
        PetState p = new PetState();
        if (!sp.contains("born")) {
            p.bornAt = now;
            p.updatedAt = now;
            p.food = 84;
            p.fun = 84;
            p.hygiene = 90;
            p.energy = 84;
            p.persist(context);
            return p;
        }
        p.bornAt = sp.getLong("born", now);
        p.updatedAt = sp.getLong("updated", now);
        p.food = clamp(sp.getInt("food", 84));
        p.fun = clamp(sp.getInt("fun", 84));
        p.hygiene = clamp(sp.getInt("hygiene", 90));
        p.energy = clamp(sp.getInt("energy", 84));
        p.sleeping = sp.getBoolean("sleeping", false);
        p.feeds = sp.getInt("feeds", 0);
        p.plays = sp.getInt("plays", 0);
        p.cleans = sp.getInt("cleans", 0);
        p.tick(context, now);
        return p;
    }

    /**
     * Fractional decay is preserved through the timestamp; while sleeping, energy recovers and
     * the other needs still decrease. A moved-back clock never grants negative elapsed time.
     */
    void tick(Context context, long now) {
        if (now <= updatedAt) return;
        // Count crossed time boundaries rather than dropping partial minutes on each redraw.
        // This stays correct even if a user opens the page every few seconds.
        long limitedNow = Math.min(now, updatedAt + 365 * DAY);
        food = clamp(food - crossed(updatedAt, limitedNow, 15 * MINUTE));
        fun = clamp(fun - crossed(updatedAt, limitedNow, 20 * MINUTE));
        hygiene = clamp(hygiene - crossed(updatedAt, limitedNow, 25 * MINUTE));
        energy = clamp(energy + (sleeping
                ? 2 * crossed(updatedAt, limitedNow, 10 * MINUTE)
                : -crossed(updatedAt, limitedNow, 30 * MINUTE)));
        updatedAt = limitedNow;
        persist(context);
    }

    /** Feed, play, clean or toggle sleep. Returns false when action is unavailable. */
    boolean act(Context context, int action) {
        tick(context, System.currentTimeMillis());
        if (action == 4) {
            sleeping = !sleeping;
        } else {
            if (sleeping) return false;
            switch (action) {
                case 1:
                    food = clamp(food + 24);
                    hygiene = clamp(hygiene - 4);
                    feeds++;
                    break;
                case 2:
                    if (energy < 8) return false;
                    fun = clamp(fun + 24);
                    energy = clamp(energy - 12);
                    food = clamp(food - 6);
                    plays++;
                    break;
                case 3:
                    hygiene = clamp(hygiene + 32);
                    fun = clamp(fun + 3);
                    cleans++;
                    break;
                default:
                    return false;
            }
        }
        persist(context);
        return true;
    }

    int ageDays(long now) {
        return 1 + (int) Math.min(99, Math.max(0L, now - bornAt) / DAY);
    }

    int stage(long now) {
        long age = Math.max(0, now - bornAt);
        if (age < HOUR) return 0;
        if (age < 12 * HOUR) return 1;
        return (food + fun + hygiene + energy) / 4 >= 35 ? 2 : 1;
    }

    String mood() {
        if (sleeping) return "SLEEPING";
        if (food < 20) return "HUNGRY";
        if (hygiene < 20) return "MESSY";
        if (energy < 20) return "TIRED";
        if (fun < 20) return "LONELY";
        return (food + fun + hygiene + energy) / 4 > 70 ? "HAPPY" : "OKAY";
    }

    private void persist(Context context) {
        prefs(context).edit().putLong("born", bornAt).putLong("updated", updatedAt)
                .putInt("food", food).putInt("fun", fun).putInt("hygiene", hygiene)
                .putInt("energy", energy).putBoolean("sleeping", sleeping)
                .putInt("feeds", feeds).putInt("plays", plays).putInt("cleans", cleans).apply();
    }

    private static SharedPreferences prefs(Context context) {
        return context.createDeviceProtectedStorageContext()
                .getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    private static int crossed(long from, long to, long step) {
        return (int) ((to / step) - (from / step));
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
